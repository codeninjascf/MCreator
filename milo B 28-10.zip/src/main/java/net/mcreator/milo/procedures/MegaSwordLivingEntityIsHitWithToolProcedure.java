package net.mcreator.milo.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;

public class MegaSwordLivingEntityIsHitWithToolProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		entity.hurt(DamageSource.GENERIC,
				entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)
						? _livEnt.getEffect(MobEffects.MOVEMENT_SLOWDOWN).getAmplifier()
						: 0);
		entity.hurt(DamageSource.GENERIC,
				entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.WEAKNESS)
						? _livEnt.getEffect(MobEffects.WEAKNESS).getAmplifier()
						: 0);
		if (world instanceof Level _level && !_level.isClientSide())
			_level.explode(null, x, y, z, 4, Explosion.BlockInteraction.BREAK);
	}
}
