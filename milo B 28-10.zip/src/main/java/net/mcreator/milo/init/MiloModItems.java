
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.milo.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.milo.item.MegaSwordItem;
import net.mcreator.milo.item.KnockbackSwordItem;
import net.mcreator.milo.MiloMod;

public class MiloModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MiloMod.MODID);
	public static final RegistryObject<Item> SPEED_BLOCK = block(MiloModBlocks.SPEED_BLOCK, CreativeModeTab.TAB_MISC);
	public static final RegistryObject<Item> JUMP_BLOCK = block(MiloModBlocks.JUMP_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> KNOCKBACK_SWORD = REGISTRY.register("knockback_sword", () -> new KnockbackSwordItem());
	public static final RegistryObject<Item> MEGA_SWORD = REGISTRY.register("mega_sword", () -> new MegaSwordItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
