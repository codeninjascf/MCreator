
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.milo.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.milo.block.SpeedBlockBlock;
import net.mcreator.milo.block.JumpBlockBlock;
import net.mcreator.milo.MiloMod;

public class MiloModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MiloMod.MODID);
	public static final RegistryObject<Block> SPEED_BLOCK = REGISTRY.register("speed_block", () -> new SpeedBlockBlock());
	public static final RegistryObject<Block> JUMP_BLOCK = REGISTRY.register("jump_block", () -> new JumpBlockBlock());
}
